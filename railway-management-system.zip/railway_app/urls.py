from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('search/', views.search_trains, name='search_trains'),
    path('book/<int:train_id>/', views.book_ticket, name='book_ticket'),
    path('payment/<int:booking_id>/', views.payment, name='payment'),
    path('confirmation/<str:pnr>/', views.booking_confirmation, name='booking_confirmation'),
    path('dashboard/', views.user_dashboard, name='user_dashboard'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('cancel/<int:booking_id>/', views.cancel_booking, name='cancel_booking'),
    path('booking/<str:pnr>/', views.booking_detail, name='booking_detail'),
    path('pnr-status/', views.pnr_status, name='pnr_status'),
    path('manage-train-seats/<int:train_id>/', views.manage_train_seats, name='manage_train_seats'),
]

