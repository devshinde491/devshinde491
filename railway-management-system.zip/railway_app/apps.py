from django.apps import AppConfig

class RailwayAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'railway_app'
    
    def ready(self):
        import railway_app.signals

