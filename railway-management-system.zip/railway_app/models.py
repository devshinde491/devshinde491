from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Station(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=10, unique=True)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    address = models.TextField()
    number_of_platforms = models.PositiveIntegerField(default=1)
    zone = models.CharField(max_length=50, help_text="Railway Zone (e.g., 'NR', 'SR', 'ER')", null=True, blank=True)
    station_type = models.CharField(max_length=50, choices=[
        ('JUNCTION', 'Junction'),
        ('TERMINAL', 'Terminal'),
        ('HALT', 'Halt'),
        ('REGULAR', 'Regular Station')
    ], default='REGULAR')
    has_wifi = models.BooleanField(default=False)
    has_retiring_room = models.BooleanField(default=False)
    has_food_plaza = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.name} ({self.code})"

class TrainClass(models.Model):
    name = models.CharField(max_length=50)
    code = models.CharField(max_length=10, unique=True)
    description = models.TextField()
    is_ac = models.BooleanField(default=False)
    fare_multiplier = models.DecimalField(max_digits=3, decimal_places=2, help_text="Multiplier for base fare")
    
    def __str__(self):
        return f"{self.name} ({self.code})"

class Train(models.Model):
    TRAIN_TYPES = [
        ('SUPERFAST', 'Superfast'),
        ('EXPRESS', 'Express'),
        ('PASSENGER', 'Passenger'),
        ('SHATABDI', 'Shatabdi'),
        ('RAJDHANI', 'Rajdhani'),
        ('DURONTO', 'Duronto'),
        ('GARIB_RATH', 'Garib Rath'),
        ('JAN_SHATABDI', 'Jan Shatabdi'),
        ('VANDE_BHARAT', 'Vande Bharat'),
        ('TEJAS', 'Tejas'),
    ]
    
    train_number = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    train_type = models.CharField(max_length=20, choices=TRAIN_TYPES, default='EXPRESS')
    source = models.ForeignKey(Station, on_delete=models.CASCADE, related_name='departing_trains')
    destination = models.ForeignKey(Station, on_delete=models.CASCADE, related_name='arriving_trains')
    departure_time = models.TimeField()
    arrival_time = models.TimeField()
    runs_on = models.CharField(max_length=100, help_text="Days the train runs (e.g., 'Mon,Tue,Wed')")
    distance = models.PositiveIntegerField(help_text="Distance in kilometers")
    fare_per_km = models.DecimalField(max_digits=6, decimal_places=2)
    available_classes = models.ManyToManyField(TrainClass, through='TrainClassAvailability')
    
    def __str__(self):
        return f"{self.train_number} - {self.name}"
    
    def calculate_fare(self, train_class):
        base_fare = self.fare_per_km * self.distance
        return base_fare * train_class.fare_multiplier

class TrainClassAvailability(models.Model):
    train = models.ForeignKey(Train, on_delete=models.CASCADE)
    train_class = models.ForeignKey(TrainClass, on_delete=models.CASCADE)
    total_seats = models.PositiveIntegerField()
    available_seats = models.PositiveIntegerField()
    
    class Meta:
        unique_together = ('train', 'train_class')
    
    def __str__(self):
        return f"{self.train.name} - {self.train_class.name} ({self.available_seats}/{self.total_seats})"

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    phone_number = models.CharField(max_length=15)
    address = models.TextField()
    date_of_birth = models.DateField(null=True, blank=True)
    id_proof_type = models.CharField(max_length=50, choices=[
        ('PASSPORT', 'Passport'),
        ('DRIVING_LICENSE', 'Driving License'),
        ('VOTER_ID', 'Voter ID'),
        ('AADHAR', 'Aadhar Card')
    ])
    id_proof_number = models.CharField(max_length=50)
    
    def __str__(self):
        return self.user.get_full_name() or self.user.username

class Booking(models.Model):
    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('CONFIRMED', 'Confirmed'),
        ('CANCELLED', 'Cancelled'),
        ('WAITLISTED', 'Waitlisted'),
        ('RAC', 'RAC'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookings')
    train = models.ForeignKey(Train, on_delete=models.CASCADE)
    train_class = models.ForeignKey(TrainClass, on_delete=models.CASCADE)
    booking_date = models.DateTimeField(auto_now_add=True)
    journey_date = models.DateField()
    num_passengers = models.PositiveIntegerField(default=1)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    pnr_number = models.CharField(max_length=10, unique=True)
    total_fare = models.DecimalField(max_digits=10, decimal_places=2)
    
    def __str__(self):
        return f"PNR: {self.pnr_number} - {self.user.username}"
    
    def save(self, *args, **kwargs):
        # Generate PNR if not already set
        if not self.pnr_number:
            import random
            import string
            self.pnr_number = ''.join(random.choices(string.digits, k=10))
        
        # Calculate total fare if not set
        if not self.total_fare:
            self.total_fare = self.train.calculate_fare(self.train_class) * self.num_passengers
            
        super().save(*args, **kwargs)

class Passenger(models.Model):
    BERTH_PREFERENCES = [
        ('LOWER', 'Lower'),
        ('MIDDLE', 'Middle'),
        ('UPPER', 'Upper'),
        ('SIDE_LOWER', 'Side Lower'),
        ('SIDE_UPPER', 'Side Upper'),
        ('WINDOW', 'Window'),
        ('AISLE', 'Aisle'),
        ('NO_PREFERENCE', 'No Preference'),
    ]
    
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name='passengers')
    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField()
    gender = models.CharField(max_length=10, choices=[
        ('MALE', 'Male'),
        ('FEMALE', 'Female'),
        ('OTHER', 'Other')
    ])
    seat_number = models.CharField(max_length=10, null=True, blank=True)
    berth_preference = models.CharField(max_length=20, choices=BERTH_PREFERENCES, default='NO_PREFERENCE')
    
    def __str__(self):
        return f"{self.name} - {self.booking.pnr_number}"

class TrainSchedule(models.Model):
    train = models.ForeignKey(Train, on_delete=models.CASCADE, related_name='schedules')
    station = models.ForeignKey(Station, on_delete=models.CASCADE)
    arrival_time = models.TimeField(null=True, blank=True)
    departure_time = models.TimeField(null=True, blank=True)
    day = models.PositiveIntegerField(default=1, help_text="Day of journey (1 for first day)")
    distance_from_source = models.PositiveIntegerField(help_text="Distance in kilometers")
    platform = models.CharField(max_length=5, null=True, blank=True)
    
    class Meta:
        ordering = ['day', 'arrival_time']
    
    def __str__(self):
        return f"{self.train.name} at {self.station.name}"

class Payment(models.Model):
    PAYMENT_METHODS = [
        ('CREDIT_CARD', 'Credit Card'),
        ('DEBIT_CARD', 'Debit Card'),
        ('NET_BANKING', 'Net Banking'),
        ('UPI', 'UPI'),
        ('WALLET', 'Wallet')
    ]
    
    PAYMENT_STATUS = [
        ('PENDING', 'Pending'),
        ('COMPLETED', 'Completed'),
        ('FAILED', 'Failed'),
        ('REFUNDED', 'Refunded')
    ]
    
    booking = models.OneToOneField(Booking, on_delete=models.CASCADE, related_name='payment')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_date = models.DateTimeField(auto_now_add=True)
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHODS)
    transaction_id = models.CharField(max_length=100, unique=True)
    status = models.CharField(max_length=20, choices=PAYMENT_STATUS, default='PENDING')
    
    def __str__(self):
        return f"Payment for {self.booking.pnr_number} - {self.amount}"

