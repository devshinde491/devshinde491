from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login, authenticate
from django.contrib import messages
from django.utils import timezone
from django.db.models import Q
from .models import Train, Station, Booking, Passenger, UserProfile, Payment, TrainClass, TrainClassAvailability
from django import forms
import random
import string
from datetime import datetime, timedelta

class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    phone_number = forms.CharField(max_length=15, required=True)
    address = forms.CharField(widget=forms.Textarea, required=True)
    date_of_birth = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}), required=True)
    id_proof_type = forms.ChoiceField(choices=[
        ('PASSPORT', 'Passport'),
        ('DRIVING_LICENSE', 'Driving License'),
        ('VOTER_ID', 'Voter ID'),
        ('AADHAR', 'Aadhar Card')
    ])
    id_proof_number = forms.CharField(max_length=50, required=True)

    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name', 'password1', 'password2')

class TrainSearchForm(forms.Form):
    source = forms.ModelChoiceField(queryset=Station.objects.all().order_by('name'), required=True)
    destination = forms.ModelChoiceField(queryset=Station.objects.all().order_by('name'), required=True)
    date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}), required=True)
    train_type = forms.ChoiceField(choices=[('', 'All Types')] + Train.TRAIN_TYPES, required=False)

class BookingForm(forms.Form):
    journey_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}), required=True)
    train_class = forms.ModelChoiceField(queryset=TrainClass.objects.none(), required=True)
    num_passengers = forms.IntegerField(min_value=1, max_value=6, required=True)
    
    def __init__(self, *args, **kwargs):
        train = kwargs.pop('train', None)
        super(BookingForm, self).__init__(*args, **kwargs)
        
        if train:
            # Get only available classes for this train
            self.fields['train_class'].queryset = TrainClass.objects.filter(
                trainclassavailability__train=train,
                trainclassavailability__available_seats__gt=0
            )

class PassengerForm(forms.ModelForm):
    class Meta:
        model = Passenger
        fields = ['name', 'age', 'gender', 'berth_preference']

PassengerFormSet = forms.formset_factory(PassengerForm, extra=1)

class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ['payment_method']

def home(request):
    return render(request, 'home.html')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            UserProfile.objects.create(
                user=user,
                phone_number=form.cleaned_data['phone_number'],
                address=form.cleaned_data['address'],
                date_of_birth=form.cleaned_data['date_of_birth'],
                id_proof_type=form.cleaned_data['id_proof_type'],
                id_proof_number=form.cleaned_data['id_proof_number']
            )
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            messages.success(request, f'Account created for {username}!')
            return redirect('user_dashboard')
    else:
        form = UserRegistrationForm()
    return render(request, 'register.html', {'form': form})

def search_trains(request):
    trains = []
    if request.method == 'POST':
        form = TrainSearchForm(request.POST)
        if form.is_valid():
            source = form.cleaned_data['source']
            destination = form.cleaned_data['destination']
            date = form.cleaned_data['date']
            train_type = form.cleaned_data.get('train_type')
            
            # Get day of week (0 = Monday, 6 = Sunday)
            day_of_week = date.weekday()
            day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
            day_name = day_names[day_of_week]
            
            # Find trains that run on this day between source and destination
            trains_query = Train.objects.filter(
                source=source,
                destination=destination,
                runs_on__contains=day_name
            )
            
            # Apply train type filter if provided
            if train_type:
                trains_query = trains_query.filter(train_type=train_type)
            
            # Get trains with available seats
            trains = []
            for train in trains_query:
                # Check if any class has available seats
                has_available_seats = TrainClassAvailability.objects.filter(
                    train=train,
                    available_seats__gt=0
                ).exists()
                
                if has_available_seats:
                    trains.append(train)
            
            # Store search parameters in session for booking
            request.session['search'] = {
                'source_id': source.id,
                'destination_id': destination.id,
                'date': date.strftime('%Y-%m-%d')
            }
    else:
        form = TrainSearchForm()
    
    return render(request, 'search_trains.html', {
        'form': form,
        'trains': trains
    })

@login_required
def book_ticket(request, train_id):
    train = get_object_or_404(Train, id=train_id)
    
    # Get search details from session
    search = request.session.get('search', {})
    journey_date = search.get('date')
    
    if request.method == 'POST':
        booking_form = BookingForm(request.POST, train=train)
        passenger_formset = PassengerFormSet(request.POST, prefix='passengers')
        
        if booking_form.is_valid() and passenger_formset.is_valid():
            # Get selected class
            train_class = booking_form.cleaned_data['train_class']
            num_passengers = booking_form.cleaned_data['num_passengers']
            
            # Check if enough seats are available
            class_availability = TrainClassAvailability.objects.get(
                train=train,
                train_class=train_class
            )
            
            if class_availability.available_seats < num_passengers:
                messages.error(request, f'Not enough seats available in {train_class.name} class. Only {class_availability.available_seats} seats left.')
                return redirect('book_ticket', train_id=train.id)
            
            # Create booking
            booking = Booking(
                user=request.user,
                train=train,
                train_class=train_class,
                journey_date=booking_form.cleaned_data['journey_date'],
                num_passengers=num_passengers,
                status='PENDING'
            )
            booking.save()
            
            # Add passengers
            for form in passenger_formset:
                if form.cleaned_data:
                    passenger = form.save(commit=False)
                    passenger.booking = booking
                    passenger.save()
            
            # Update available seats
            class_availability.available_seats -= num_passengers
            class_availability.save()
            
            return redirect('payment', booking_id=booking.id)
    else:
        initial_date = datetime.strptime(journey_date, '%Y-%m-%d').date() if journey_date else timezone.now().date()
        booking_form = BookingForm(initial={'journey_date': initial_date, 'num_passengers': 1}, train=train)
        passenger_formset = PassengerFormSet(prefix='passengers')
    
    # Get available classes and their seat availability
    class_availability = TrainClassAvailability.objects.filter(
        train=train,
        available_seats__gt=0
    ).select_related('train_class')
    
    return render(request, 'book_ticket.html', {
        'train': train,
        'booking_form': booking_form,
        'passenger_formset': passenger_formset,
        'class_availability': class_availability
    })

@login_required
def payment(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)
    
    if request.method == 'POST':
        form = PaymentForm(request.POST)
        if form.is_valid():
            payment = form.save(commit=False)
            payment.booking = booking
            payment.amount = booking.total_fare
            payment.transaction_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))
            payment.status = 'COMPLETED'  # In a real app, this would depend on payment gateway response
            payment.save()
            
            # Update booking status
            booking.status = 'CONFIRMED'
            booking.save()
            
            # Assign seat numbers to passengers
            seat_base = random.randint(1, 60)
            for i, passenger in enumerate(booking.passengers.all()):
                passenger.seat_number = f"{chr(65 + i % 6)}{seat_base + i // 6}"
                passenger.save()
            
            messages.success(request, f'Booking confirmed! Your PNR number is {booking.pnr_number}')
            return redirect('booking_confirmation', pnr=booking.pnr_number)
    else:
        form = PaymentForm()
    
    return render(request, 'payment.html', {
        'booking': booking,
        'form': form
    })

@login_required
def booking_confirmation(request, pnr):
    booking = get_object_or_404(Booking, pnr_number=pnr, user=request.user)
    return render(request, 'booking_confirmation.html', {'booking': booking})

@login_required
def user_dashboard(request):
    upcoming_bookings = Booking.objects.filter(
        user=request.user,
        journey_date__gte=timezone.now().date(),
        status='CONFIRMED'
    ).order_by('journey_date')
    
    past_bookings = Booking.objects.filter(
        user=request.user,
        journey_date__lt=timezone.now().date(),
        status='CONFIRMED'
    ).order_by('-journey_date')
    
    return render(request, 'user_dashboard.html', {
        'upcoming_bookings': upcoming_bookings,
        'past_bookings': past_bookings
    })

@login_required
def cancel_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)
    
    # Only allow cancellation for future journeys
    if booking.journey_date <= timezone.now().date():
        messages.error(request, 'Cannot cancel bookings for past or current dates')
        return redirect('user_dashboard')
    
    if request.method == 'POST':
        booking.status = 'CANCELLED'
        booking.save()
        
        # Process refund (in a real app)
        if hasattr(booking, 'payment'):
            booking.payment.status = 'REFUNDED'
            booking.payment.save()
        
        # Increase available seats
        try:
            class_availability = TrainClassAvailability.objects.get(
                train=booking.train,
                train_class=booking.train_class
            )
            class_availability.available_seats += booking.num_passengers
            class_availability.save()
        except TrainClassAvailability.DoesNotExist:
            pass
        
        messages.success(request, f'Booking {booking.pnr_number} has been cancelled')
        return redirect('user_dashboard')
    
    return render(request, 'cancel_booking.html', {'booking': booking})

@login_required
def booking_detail(request, pnr):
    booking = get_object_or_404(Booking, pnr_number=pnr, user=request.user)
    return render(request, 'booking_detail.html', {'booking': booking})

def pnr_status(request):
    booking = None
    if request.method == 'POST':
        pnr = request.POST.get('pnr')
        if pnr:
            booking = Booking.objects.filter(pnr_number=pnr).first()
    
    return render(request, 'pnr_status.html', {'booking': booking})

@login_required
def admin_dashboard(request):
    # Only allow staff members
    if not request.user.is_staff:
        messages.error(request, 'You do not have permission to access this page')
        return redirect('home')
    
    today = timezone.now().date()
    
    # Get statistics
    total_bookings = Booking.objects.count()
    confirmed_bookings = Booking.objects.filter(status='CONFIRMED').count()
    cancelled_bookings = Booking.objects.filter(status='CANCELLED').count()
    today_bookings = Booking.objects.filter(booking_date__date=today).count()
    
    # Get recent bookings
    recent_bookings = Booking.objects.all().order_by('-booking_date')[:10]
    
    # Get trains for management
    trains = Train.objects.all().order_by('train_number')
    
    return render(request, 'admin_dashboard.html', {
        'total_bookings': total_bookings,
        'confirmed_bookings': confirmed_bookings,
        'cancelled_bookings': cancelled_bookings,
        'today_bookings': today_bookings,
        'recent_bookings': recent_bookings,
        'trains': trains
    })

@login_required
def manage_train_seats(request, train_id):
    # Only allow staff members
    if not request.user.is_staff:
        messages.error(request, 'You do not have permission to access this page')
        return redirect('home')
    
    train = get_object_or_404(Train, id=train_id)
    class_availability = TrainClassAvailability.objects.filter(train=train)
    
    if request.method == 'POST':
        for class_avail in class_availability:
            total_seats_key = f'total_seats_{class_avail.id}'
            available_seats_key = f'available_seats_{class_avail.id}'
            
            if total_seats_key in request.POST and available_seats_key in request.POST:
                try:
                    total_seats = int(request.POST[total_seats_key])
                    available_seats = int(request.POST[available_seats_key])
                    
                    if total_seats < 0 or available_seats < 0:
                        messages.error(request, 'Seats cannot be negative')
                        continue
                    
                    if available_seats > total_seats:
                        messages.error(request, f'Available seats cannot exceed total seats for {class_avail.train_class.name}')
                        continue
                    
                    class_avail.total_seats = total_seats
                    class_avail.available_seats = available_seats
                    class_avail.save()
                    
                except ValueError:
                    messages.error(request, 'Invalid seat numbers')
        
        messages.success(request, f'Seat availability for {train.name} updated successfully')
        return redirect('manage_train_seats', train_id=train.id)
    
    return render(request, 'manage_train_seats.html', {
        'train': train,
        'class_availability': class_availability
    })

