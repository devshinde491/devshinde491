from django.contrib import admin
from .models import (
    Station, Train, UserProfile, Booking, 
    Passenger, TrainSchedule, Payment, TrainClass,
    TrainClassAvailability
)

@admin.register(Station)
class StationAdmin(admin.ModelAdmin):
    list_display = ('name', 'code', 'city', 'state', 'zone', 'station_type', 'number_of_platforms')
    search_fields = ('name', 'code', 'city')
    list_filter = ('state', 'zone', 'station_type', 'has_wifi', 'has_retiring_room', 'has_food_plaza')

@admin.register(TrainClass)
class TrainClassAdmin(admin.ModelAdmin):
    list_display = ('name', 'code', 'is_ac', 'fare_multiplier')
    search_fields = ('name', 'code')
    list_filter = ('is_ac',)

class TrainClassAvailabilityInline(admin.TabularInline):
    model = TrainClassAvailability
    extra = 1

class TrainScheduleInline(admin.TabularInline):
    model = TrainSchedule
    extra = 1

@admin.register(Train)
class TrainAdmin(admin.ModelAdmin):
    list_display = ('train_number', 'name', 'train_type', 'source', 'destination', 'departure_time', 'arrival_time')
    search_fields = ('train_number', 'name')
    list_filter = ('train_type', 'source', 'destination')
    inlines = [TrainClassAvailabilityInline, TrainScheduleInline]
    
    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        form.base_fields['source'].queryset = Station.objects.all().order_by('name')
        form.base_fields['destination'].queryset = Station.objects.all().order_by('name')
        return form

@admin.register(TrainClassAvailability)
class TrainClassAvailabilityAdmin(admin.ModelAdmin):
    list_display = ('train', 'train_class', 'total_seats', 'available_seats')
    search_fields = ('train__name', 'train__train_number', 'train_class__name')
    list_filter = ('train_class',)
    
    def get_readonly_fields(self, request, obj=None):
        if obj:  # editing an existing object
            return ('train', 'train_class')
        return ()

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone_number', 'id_proof_type')
    search_fields = ('user__username', 'user__email', 'phone_number')

class PassengerInline(admin.TabularInline):
    model = Passenger
    extra = 1

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('pnr_number', 'user', 'train', 'train_class', 'journey_date', 'status', 'total_fare')
    search_fields = ('pnr_number', 'user__username')
    list_filter = ('status', 'journey_date', 'train_class')
    inlines = [PassengerInline]

@admin.register(Passenger)
class PassengerAdmin(admin.ModelAdmin):
    list_display = ('name', 'booking', 'age', 'gender', 'seat_number', 'berth_preference')
    search_fields = ('name', 'booking__pnr_number')
    list_filter = ('gender', 'berth_preference')

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('booking', 'amount', 'payment_method', 'status', 'payment_date')
    search_fields = ('booking__pnr_number', 'transaction_id')
    list_filter = ('status', 'payment_method')

@admin.register(TrainSchedule)
class TrainScheduleAdmin(admin.ModelAdmin):
    list_display = ('train', 'station', 'arrival_time', 'departure_time', 'platform')
    search_fields = ('train__name', 'station__name')
    list_filter = ('train', 'station')

