from django.core.management.base import BaseCommand
from railway_app.models import Train, Station, TrainClass, TrainClassAvailability
from django.db import transaction
import random
from datetime import time

class Command(BaseCommand):
    help = 'Seeds the database with sample trains for Indian Railways'

    @transaction.atomic
    def handle(self, *args, **kwargs):
        self.stdout.write('Seeding trains...')
        
        # Create sample trains
        self.create_sample_trains()
        
        self.stdout.write(self.style.SUCCESS('Trains seeded successfully!'))
    
    def create_sample_trains(self):
        # Get all stations and train classes
        stations = list(Station.objects.all())
        train_classes = list(TrainClass.objects.all())
        
        if not stations or len(stations) < 2:
            self.stdout.write(self.style.ERROR('Not enough stations in the database. Please run seed_data first.'))
            return
        
        if not train_classes:
            self.stdout.write(self.style.ERROR('No train classes in the database. Please run seed_data first.'))
            return
        
        # Sample train data
        train_data = [
            {
                'train_number': '12301',
                'name': 'Howrah Rajdhani Express',
                'train_type': 'RAJDHANI',
                'source_code': 'NDLS',
                'destination_code': 'HWH',
                'departure_time': time(16, 55),
                'arrival_time': time(9, 55),
                'runs_on': 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',
                'distance': 1451,
                'fare_per_km': 1.5
            },
            {
                'train_number': '12951',
                'name': 'Mumbai Rajdhani Express',
                'train_type': 'RAJDHANI',
                'source_code': 'NDLS',
                'destination_code': 'MMCT',
                'departure_time': time(16, 25),
                'arrival_time': time(8, 15),
                'runs_on': 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',
                'distance': 1386,
                'fare_per_km': 1.5
            },
            {
                'train_number': '12953',
                'name': 'August Kranti Rajdhani Express',
                'train_type': 'RAJDHANI',
                'source_code': 'NDLS',
                'destination_code': 'MMCT',
                'departure_time': time(17, 15),
                'arrival_time': time(10, 5),
                'runs_on': 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',
                'distance': 1377,
                'fare_per_km': 1.5
            },
            {
                'train_number': '12309',
                'name': 'Rajendra Nagar Rajdhani Express',
                'train_type': 'RAJDHANI',
                'source_code': 'NDLS',
                'destination_code': 'PNBE',
                'departure_time': time(19, 15),
                'arrival_time': time(7, 40),
                'runs_on': 'Mon,Wed,Fri,Sun',
                'distance': 1001,
                'fare_per_km': 1.5
            },
            {
                'train_number': '12001',
                'name': 'Bhopal Shatabdi Express',
                'train_type': 'SHATABDI',
                'source_code': 'NDLS',
                'destination_code': 'BPL',
                'departure_time': time(6, 15),
                'arrival_time': time(14, 30),
                'runs_on': 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',
                'distance': 707,
                'fare_per_km': 1.8
            },
            {
                'train_number': '12002',
                'name': 'New Delhi Shatabdi Express',
                'train_type': 'SHATABDI',
                'source_code': 'BPL',
                'destination_code': 'NDLS',
                'departure_time': time(15, 25),
                'arrival_time': time(23, 30),
                'runs_on': 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',
                'distance': 707,
                'fare_per_km': 1.8
            },
            {
                'train_number': '12259',
                'name': 'Sealdah Duronto Express',
                'train_type': 'DURONTO',
                'source_code': 'NDLS',
                'destination_code': 'HWH',
                'departure_time': time(12, 55),
                'arrival_time': time(3, 55),
                'runs_on': 'Mon,Thu',
                'distance': 1453,
                'fare_per_km': 1.6
            },
            {
                'train_number': '12019',
                'name': 'Howrah Shatabdi Express',
                'train_type': 'SHATABDI',
                'source_code': 'NDLS',
                'destination_code': 'HWH',
                'departure_time': time(6, 0),
                'arrival_time': time(14, 0),
                'runs_on': 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',
                'distance': 1451,
                'fare_per_km': 1.8
            },
            {
                'train_number': '22221',
                'name': 'Mumbai CSMT Rajdhani Express',
                'train_type': 'RAJDHANI',
                'source_code': 'NDLS',
                'destination_code': 'CSMT',
                'departure_time': time(16, 10),
                'arrival_time': time(8, 35),
                'runs_on': 'Wed,Fri,Sun',
                'distance': 1543,
                'fare_per_km': 1.5
            },
            {
                'train_number': '12723',
                'name': 'Telangana Express',
                'train_type': 'SUPERFAST',
                'source_code': 'NDLS',
                'destination_code': 'SC',
                'departure_time': time(6, 40),
                'arrival_time': time(3, 15),
                'runs_on': 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',
                'distance': 1661,
                'fare_per_km': 1.3
            },
            {
                'train_number': '12303',
                'name': 'Poorva Express',
                'train_type': 'SUPERFAST',
                'source_code': 'HWH',
                'destination_code': 'NDLS',
                'departure_time': time(8, 10),
                'arrival_time': time(7, 50),
                'runs_on': 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',
                'distance': 1451,
                'fare_per_km': 1.3
            },
            {
                'train_number': '12305',
                'name': 'Howrah-New Delhi Rajdhani Express',
                'train_type': 'RAJDHANI',
                'source_code': 'HWH',
                'destination_code': 'NDLS',
                'departure_time': time(16, 55),
                'arrival_time': time(10, 0),
                'runs_on': 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',
                'distance': 1451,
                'fare_per_km': 1.5
            },
            {
                'train_number': '12313',
                'name': 'Sealdah Rajdhani Express',
                'train_type': 'RAJDHANI',
                'source_code': 'NDLS',
                'destination_code': 'HWH',
                'departure_time': time(16, 30),
                'arrival_time': time(10, 10),
                'runs_on': 'Mon,Wed,Fri',
                'distance': 1447,
                'fare_per_km': 1.5
            },
            {
                'train_number': '12565',
                'name': 'Bihar Sampark Kranti Express',
                'train_type': 'SUPERFAST',
                'source_code': 'NDLS',
                'destination_code': 'PNBE',
                'departure_time': time(13, 15),
                'arrival_time': time(4, 50),
                'runs_on': 'Mon,Wed,Thu,Sat',
                'distance': 1001,
                'fare_per_km': 1.3
            },
            {
                'train_number': '12801',
                'name': 'Purushottam Express',
                'train_type': 'SUPERFAST',
                'source_code': 'PNBE',
                'destination_code': 'NDLS',
                'departure_time': time(19, 10),
                'arrival_time': time(10, 25),
                'runs_on': 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',
                'distance': 1001,
                'fare_per_km': 1.3
            },
            {
                'train_number': '22691',
                'name': 'Rajdhani Express',
                'train_type': 'RAJDHANI',
                'source_code': 'NDLS',
                'destination_code': 'BZA',
                'departure_time': time(15, 55),
                'arrival_time': time(15, 40),
                'runs_on': 'Wed,Fri,Sun',
                'distance': 2054,
                'fare_per_km': 1.5
            },
            {
                'train_number': '12957',
                'name': 'Swarna Jayanti Rajdhani Express',
                'train_type': 'RAJDHANI',
                'source_code': 'NDLS',
                'destination_code': 'ADI',
                'departure_time': time(19, 55),
                'arrival_time': time(8, 25),
                'runs_on': 'Mon,Thu,Sat',
                'distance': 934,
                'fare_per_km': 1.5
            },
            {
                'train_number': '12909',
                'name': 'Mumbai Bandra Terminus - Hazrat Nizamuddin Garib Rath Express',
                'train_type': 'GARIB_RATH',
                'source_code': 'MMCT',
                'destination_code': 'NDLS',
                'departure_time': time(12, 40),
                'arrival_time': time(4, 10),
                'runs_on': 'Tue,Thu,Sun',
                'distance': 1386,
                'fare_per_km': 1.0
            },
            {
                'train_number': '12951',
                'name': 'Mumbai Rajdhani Express',
                'train_type': 'RAJDHANI',
                'source_code': 'MMCT',
                'destination_code': 'NDLS',
                'departure_time': time(17, 0),
                'arrival_time': time(8, 35),
                'runs_on': 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',
                'distance': 1386,
                'fare_per_km': 1.5
            },
            {
                'train_number': '22201',
                'name': 'Sealdah - Puri Duronto Express',
                'train_type': 'DURONTO',
                'source_code': 'HWH',
                'destination_code': 'BBS',
                'departure_time': time(20, 0),
                'arrival_time': time(4, 0),
                'runs_on': 'Mon,Wed,Fri',
                'distance': 500,
                'fare_per_km': 1.6
            }
        ]
        
        # Create trains
        for data in train_data:
            source = Station.objects.get(code=data['source_code'])
            destination = Station.objects.get(code=data['destination_code'])
            
            train, created = Train.objects.get_or_create(
                train_number=data['train_number'],
                defaults={
                    'name': data['name'],
                    'train_type': data['train_type'],
                    'source': source,
                    'destination': destination,
                    'departure_time': data['departure_time'],
                    'arrival_time': data['arrival_time'],
                    'runs_on': data['runs_on'],
                    'distance': data['distance'],
                    'fare_per_km': data['fare_per_km']
                }
            )
            
            if created:
                # Add train classes with random seat availability
                for train_class in train_classes:
                    # Skip some classes based on train type
                    if data['train_type'] == 'RAJDHANI' and train_class.code in ['2S', 'SL']:
                        continue
                    if data['train_type'] == 'SHATABDI' and train_class.code in ['SL', '1A', '2A', '3A']:
                        continue
                    if data['train_type'] == 'GARIB_RATH' and train_class.code in ['1A', 'EC', '2S']:
                        continue
                    
                    # Determine total seats based on class
                    if train_class.code == '1A':
                        total_seats = random.randint(18, 24)
                    elif train_class.code == '2A':
                        total_seats = random.randint(46, 54)
                    elif train_class.code == '3A':
                        total_seats = random.randint(64, 72)
                    elif train_class.code == 'SL':
                        total_seats = random.randint(72, 80)
                    elif train_class.code == '2S':
                        total_seats = random.randint(108, 120)
                    elif train_class.code == 'CC':
                        total_seats = random.randint(78, 85)
                    elif train_class.code == 'EC':
                        total_seats = random.randint(56, 64)
                    else:
                        total_seats = random.randint(60, 72)
                    
                    # Available seats is a random number between 0 and total seats
                    available_seats = random.randint(0, total_seats)
                    
                    TrainClassAvailability.objects.create(
                        train=train,
                        train_class=train_class,
                        total_seats=total_seats,
                        available_seats=available_seats
                    )
        
        self.stdout.write(f'Created {len(train_data)} trains with class availability')

