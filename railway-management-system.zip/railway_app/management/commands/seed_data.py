from django.core.management.base import BaseCommand
from railway_app.models import Station, TrainClass
from django.db import transaction

class Command(BaseCommand):
    help = 'Seeds the database with initial data for Indian Railways'

    @transaction.atomic
    def handle(self, *args, **kwargs):
        self.stdout.write('Seeding database...')
        
        # Create train classes
        self.create_train_classes()
        
        # Create stations
        self.create_stations()
        
        self.stdout.write(self.style.SUCCESS('Database seeded successfully!'))
    
    def create_train_classes(self):
        train_classes = [
            {
                'name': 'AC First Class',
                'code': '1A',
                'description': 'Air-conditioned first class: Most expensive class, with lockable 2-bed and 4-bed cabins.',
                'is_ac': True,
                'fare_multiplier': 3.0
            },
            {
                'name': 'AC 2 Tier',
                'code': '2A',
                'description': 'Air-conditioned two tier: Comfortable air-conditioned coaches with curtained berths.',
                'is_ac': True,
                'fare_multiplier': 2.5
            },
            {
                'name': 'AC 3 Tier',
                'code': '3A',
                'description': 'Air-conditioned three tier: Air-conditioned coaches with 3 berths vertically stacked.',
                'is_ac': True,
                'fare_multiplier': 2.0
            },
            {
                'name': 'AC Chair Car',
                'code': 'CC',
                'description': 'Air-conditioned chair car: Air-conditioned seating coaches for short journeys.',
                'is_ac': True,
                'fare_multiplier': 1.8
            },
            {
                'name': 'Sleeper Class',
                'code': 'SL',
                'description': 'Sleeper class: Non-AC coach with 3 berths vertically stacked.',
                'is_ac': False,
                'fare_multiplier': 1.0
            },
            {
                'name': 'Second Sitting',
                'code': '2S',
                'description': 'Second sitting: Seating coaches for short journeys.',
                'is_ac': False,
                'fare_multiplier': 0.8
            },
            {
                'name': 'Executive Chair Car',
                'code': 'EC',
                'description': 'Executive chair car: Luxurious seating for Shatabdi and similar trains.',
                'is_ac': True,
                'fare_multiplier': 2.2
            },
            {
                'name': 'AC 3 Tier Economy',
                'code': '3E',
                'description': 'AC 3 Tier Economy: Economical version of 3A with more berths per coach.',
                'is_ac': True,
                'fare_multiplier': 1.7
            },
        ]
        
        for train_class_data in train_classes:
            TrainClass.objects.get_or_create(
                code=train_class_data['code'],
                defaults=train_class_data
            )
        
        self.stdout.write(f'Created {len(train_classes)} train classes')
    
    def create_stations(self):
        stations = [
            {
                'name': 'New Delhi Railway Station',
                'code': 'NDLS',
                'city': 'New Delhi',
                'state': 'Delhi',
                'address': 'Paharganj, New Delhi, Delhi 110055',
                'number_of_platforms': 16,
                'zone': 'NR',
                'station_type': 'TERMINAL',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Mumbai Central',
                'code': 'MMCT',
                'city': 'Mumbai',
                'state': 'Maharashtra',
                'address': 'Mumbai Central, Mumbai, Maharashtra 400008',
                'number_of_platforms': 5,
                'zone': 'WR',
                'station_type': 'TERMINAL',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Chhatrapati Shivaji Terminus',
                'code': 'CSMT',
                'city': 'Mumbai',
                'state': 'Maharashtra',
                'address': 'Fort, Mumbai, Maharashtra 400001',
                'number_of_platforms': 18,
                'zone': 'CR',
                'station_type': 'TERMINAL',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Howrah Junction',
                'code': 'HWH',
                'city': 'Howrah',
                'state': 'West Bengal',
                'address': 'Howrah, West Bengal 711101',
                'number_of_platforms': 23,
                'zone': 'ER',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Chennai Central',
                'code': 'MAS',
                'city': 'Chennai',
                'state': 'Tamil Nadu',
                'address': 'Chennai, Tamil Nadu 600003',
                'number_of_platforms': 12,
                'zone': 'SR',
                'station_type': 'TERMINAL',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Bengaluru City Junction',
                'code': 'SBC',
                'city': 'Bengaluru',
                'state': 'Karnataka',
                'address': 'Majestic, Bengaluru, Karnataka 560023',
                'number_of_platforms': 10,
                'zone': 'SWR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Ahmedabad Junction',
                'code': 'ADI',
                'city': 'Ahmedabad',
                'state': 'Gujarat',
                'address': 'Kalupur, Ahmedabad, Gujarat 380002',
                'number_of_platforms': 12,
                'zone': 'WR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Pune Junction',
                'code': 'PUNE',
                'city': 'Pune',
                'state': 'Maharashtra',
                'address': 'Pune, Maharashtra 411001',
                'number_of_platforms': 6,
                'zone': 'CR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Jaipur Junction',
                'code': 'JP',
                'city': 'Jaipur',
                'state': 'Rajasthan',
                'address': 'Jaipur, Rajasthan 302006',
                'number_of_platforms': 6,
                'zone': 'NWR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Lucknow Charbagh',
                'code': 'LKO',
                'city': 'Lucknow',
                'state': 'Uttar Pradesh',
                'address': 'Charbagh, Lucknow, Uttar Pradesh 226004',
                'number_of_platforms': 9,
                'zone': 'NR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Kanpur Central',
                'code': 'CNB',
                'city': 'Kanpur',
                'state': 'Uttar Pradesh',
                'address': 'Kanpur, Uttar Pradesh 208001',
                'number_of_platforms': 10,
                'zone': 'NCR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Secunderabad Junction',
                'code': 'SC',
                'city': 'Hyderabad',
                'state': 'Telangana',
                'address': 'Secunderabad, Telangana 500003',
                'number_of_platforms': 10,
                'zone': 'SCR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Vijayawada Junction',
                'code': 'BZA',
                'city': 'Vijayawada',
                'state': 'Andhra Pradesh',
                'address': 'Vijayawada, Andhra Pradesh 520003',
                'number_of_platforms': 10,
                'zone': 'SCR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Bhopal Junction',
                'code': 'BPL',
                'city': 'Bhopal',
                'state': 'Madhya Pradesh',
                'address': 'Bhopal, Madhya Pradesh 462001',
                'number_of_platforms': 6,
                'zone': 'WCR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Patna Junction',
                'code': 'PNBE',
                'city': 'Patna',
                'state': 'Bihar',
                'address': 'Patna, Bihar 800001',
                'number_of_platforms': 10,
                'zone': 'ECR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Guwahati',
                'code': 'GHY',
                'city': 'Guwahati',
                'state': 'Assam',
                'address': 'Guwahati, Assam 781001',
                'number_of_platforms': 7,
                'zone': 'NFR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Agra Cantt',
                'code': 'AGC',
                'city': 'Agra',
                'state': 'Uttar Pradesh',
                'address': 'Agra, Uttar Pradesh 282001',
                'number_of_platforms': 6,
                'zone': 'NCR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Varanasi Junction',
                'code': 'BSB',
                'city': 'Varanasi',
                'state': 'Uttar Pradesh',
                'address': 'Varanasi, Uttar Pradesh 221002',
                'number_of_platforms': 9,
                'zone': 'NER',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Amritsar Junction',
                'code': 'ASR',
                'city': 'Amritsar',
                'state': 'Punjab',
                'address': 'Amritsar, Punjab 143001',
                'number_of_platforms': 6,
                'zone': 'NR',
                'station_type': 'JUNCTION',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            },
            {
                'name': 'Jammu Tawi',
                'code': 'JAT',
                'city': 'Jammu',
                'state': 'Jammu and Kashmir',
                'address': 'Jammu, Jammu and Kashmir 180002',
                'number_of_platforms': 3,
                'zone': 'NR',
                'station_type': 'TERMINAL',
                'has_wifi': True,
                'has_retiring_room': True,
                'has_food_plaza': True
            }
        ]
        
        for station_data in stations:
            Station.objects.get_or_create(
                code=station_data['code'],
                defaults=station_data
            )
        
        self.stdout.write(f'Created {len(stations)} stations')

