# Railway Management System

A comprehensive web application for managing railway operations, built with Django.

## Features

- User registration and authentication
- Train search and booking
- PNR status checking
- Booking management (view, cancel)
- Admin dashboard for system management
- Payment processing

## Installation

1. Clone the repository:
   \`\`\`
   git clone https://github.com/yourusername/railway-management-system.git
   cd railway-management-system
   \`\`\`

2. Create a virtual environment and activate it:
   \`\`\`
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   \`\`\`

3. Install dependencies:
   \`\`\`
   pip install -r requirements.txt
   \`\`\`

4. Apply migrations:
   \`\`\`
   python manage.py migrate
   \`\`\`

5. Create a superuser:
   \`\`\`
   python manage.py createsuperuser
   \`\`\`

6. Seed the database with Indian train stations and train classes:
   \`\`\`
   python manage.py seed_data
   \`\`\`

7. Seed the database with sample trains:
   \`\`\`
   python manage.py seed_trains
   \`\`\`

8. Run the development server:
   \`\`\`
   python manage.py runserver
   \`\`\`

9. Access the application at http://127.0.0.1:8000/

