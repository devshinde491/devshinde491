#!/usr/bin/env python
import os
import subprocess

# Configuration
REPO_URL = 'git@github.com:yourusername/railway-management.git'
PROJECT_DIR = '/var/www/railway-management'
VENV_DIR = os.path.join(PROJECT_DIR, 'venv')
PYTHON = os.path.join(VENV_DIR, 'bin', 'python')
PIP = os.path.join(VENV_DIR, 'bin', 'pip')

# Create project directory if it doesn't exist
if not os.path.exists(PROJECT_DIR):
    os.makedirs(PROJECT_DIR)
    # Clone the repository
    subprocess.run(['git', 'clone', REPO_URL, PROJECT_DIR])
else:
    # Pull latest changes
    os.chdir(PROJECT_DIR)
    subprocess.run(['git', 'pull'])

# Create virtual environment if it doesn't exist
if not os.path.exists(VENV_DIR):
    subprocess.run(['python3', '-m', 'venv', VENV_DIR])

# Install/update dependencies
subprocess.run([PIP, 'install', '-r', os.path.join(PROJECT_DIR, 'requirements.txt')])

# Run migrations
subprocess.run([PYTHON, 'manage.py', 'migrate'])

# Collect static files
subprocess.run([PYTHON, 'manage.py', 'collectstatic', '--noinput'])

# Restart Gunicorn (assuming it's set up with systemd)
subprocess.run(['sudo', 'systemctl', 'restart', 'railway-management'])

print("Deployment completed successfully!")

