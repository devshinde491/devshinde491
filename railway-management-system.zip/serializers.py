# Install Django REST Framework: pip install djangorestframework

# trains/serializers.py
from rest_framework import serializers
from .models import Train
from stations.models import Station

class StationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Station
        fields = ['id', 'code', 'name', 'city']

class TrainSerializer(serializers.ModelSerializer):
    source = StationSerializer(read_only=True)
    destination = StationSerializer(read_only=True)
    
    class Meta:
        model = Train
        fields = ['id', 'train_number', 'name', 'source', 'destination', 
                  'departure_time', 'arrival_time', 'available_seats']

# bookings/serializers.py
from rest_framework import serializers
from .models import Booking
from trains.serializers import TrainSerializer
from passengers.serializers import PassengerSerializer

class BookingSerializer(serializers.ModelSerializer):
    train = TrainSerializer(read_only=True)
    passenger = PassengerSerializer(read_only=True)
    
    class Meta:
        model = Booking
        fields = ['id', 'passenger', 'train', 'booking_date', 'journey_date', 
                  'seat_number', 'status', 'amount']

