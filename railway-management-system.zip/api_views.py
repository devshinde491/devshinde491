# trains/api_views.py
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Train
from .serializers import TrainSerializer
from rest_framework.filters import SearchFilter
from django_filters.rest_framework import DjangoFilterBackend

class TrainViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Train.objects.all()
    serializer_class = TrainSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter]
    filterset_fields = ['source__code', 'destination__code']
    search_fields = ['name', 'train_number']

# bookings/api_views.py
from rest_framework import viewsets, permissions
from .models import Booking
from .serializers import BookingSerializer
from rest_framework.decorators import action
from rest_framework.response import Response

class BookingViewSet(viewsets.ModelViewSet):
    serializer_class = BookingSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        # Regular users can only see their own bookings
        if self.request.user.is_staff:
            return Booking.objects.all()
        return Booking.objects.filter(passenger=self.request.user.passenger)
    
    def perform_create(self, serializer):
        serializer.save(passenger=self.request.user.passenger)
        
    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        booking = self.get_object()
        booking.status = 'CANCELLED'
        booking.save()
        
        # Increase available seats
        train = booking.train
        train.available_seats += 1
        train.save()
        
        return Response({'status': 'booking cancelled'})

