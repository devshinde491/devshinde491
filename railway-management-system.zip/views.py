# trains/views.py
from django.shortcuts import render
from django.views import generic
from .models import Train
from stations.models import Station
from django.db.models import Q

class TrainListView(generic.ListView):
    model = Train
    template_name = 'trains/train_list.html'
    context_object_name = 'trains'
    
    def get_queryset(self):
        queryset = Train.objects.all()
        source = self.request.GET.get('source')
        destination = self.request.GET.get('destination')
        date = self.request.GET.get('date')
        
        if source and destination:
            queryset = queryset.filter(
                Q(source__code=source) & Q(destination__code=destination)
            )
        
        if date:
            queryset = queryset.filter(departure_time__date=date)
            
        return queryset

# bookings/views.py
from django.shortcuts import render, redirect
from django.views import generic
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import Booking
from trains.models import Train
from django.urls import reverse_lazy

class BookingCreateView(LoginRequiredMixin, generic.CreateView):
    model = Booking
    fields = ['train', 'journey_date', 'seat_number']
    template_name = 'bookings/booking_form.html'
    success_url = reverse_lazy('booking-list')
    
    def form_valid(self, form):
        form.instance.passenger = self.request.user.passenger
        train = form.cleaned_data['train']
        
        # Check seat availability
        if train.available_seats <= 0:
            form.add_error('train', 'No seats available for this train')
            return self.form_invalid(form)
            
        # Calculate amount (simplified)
        form.instance.amount = 500.00  # In a real app, this would be calculated based on distance, class, etc.
        
        # Update available seats
        train.available_seats -= 1
        train.save()
        
        return super().form_valid(form)

class BookingListView(LoginRequiredMixin, generic.ListView):
    model = Booking
    template_name = 'bookings/booking_list.html'
    context_object_name = 'bookings'
    
    def get_queryset(self):
        return Booking.objects.filter(passenger=self.request.user.passenger)

