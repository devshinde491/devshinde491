# Terminal commands to set up the Django project
# pip install django
# django-admin startproject railway_management
# cd railway_management
# python manage.py startapp trains
# python manage.py startapp passengers
# python manage.py startapp bookings
# python manage.py startapp stations

