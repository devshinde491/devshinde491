# trains/models.py
from django.db import models

class Train(models.Model):
    train_number = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    source = models.ForeignKey('stations.Station', on_delete=models.CASCADE, related_name='source_trains')
    destination = models.ForeignKey('stations.Station', on_delete=models.CASCADE, related_name='destination_trains')
    departure_time = models.DateTimeField()
    arrival_time = models.DateTimeField()
    total_seats = models.IntegerField()
    available_seats = models.IntegerField()
    
    def __str__(self):
        return f"{self.train_number} - {self.name}"

# stations/models.py
class Station(models.Model):
    code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    number_of_platforms = models.IntegerField()
    
    def __str__(self):
        return f"{self.code} - {self.name}"

# passengers/models.py
from django.contrib.auth.models import User

class Passenger(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=15)
    address = models.TextField()
    date_of_birth = models.DateField()
    
    def __str__(self):
        return self.user.get_full_name()

# bookings/models.py
class Booking(models.Model):
    STATUS_CHOICES = (
        ('PENDING', 'Pending'),
        ('CONFIRMED', 'Confirmed'),
        ('CANCELLED', 'Cancelled'),
    )
    
    passenger = models.ForeignKey('passengers.Passenger', on_delete=models.CASCADE)
    train = models.ForeignKey('trains.Train', on_delete=models.CASCADE)
    booking_date = models.DateTimeField(auto_now_add=True)
    journey_date = models.DateField()
    seat_number = models.CharField(max_length=10)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    
    def __str__(self):
        return f"Booking {self.id} - {self.passenger.user.get_full_name()}"

