# railway_management/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('trains/', include('trains.urls')),
    path('bookings/', include('bookings.urls')),
    path('passengers/', include('passengers.urls')),
    path('stations/', include('stations.urls')),
    path('accounts/', include('django.contrib.auth.urls')),
]

# trains/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.TrainListView.as_view(), name='train-list'),
    path('<int:pk>/', views.TrainDetailView.as_view(), name='train-detail'),
]

# bookings/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.BookingListView.as_view(), name='booking-list'),
    path('create/', views.BookingCreateView.as_view(), name='booking-create'),
    path('<int:pk>/', views.BookingDetailView.as_view(), name='booking-detail'),
    path('<int:pk>/cancel/', views.BookingCancelView.as_view(), name='booking-cancel'),
]

