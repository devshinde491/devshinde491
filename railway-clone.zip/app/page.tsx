import { Nav } from "@/components/nav"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Nav />
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to Railway Reservation System</h1>
          <p className="text-xl text-gray-600 mb-8">Book your train tickets easily and efficiently.</p>
          <div className="space-x-4">
            <Button asChild>
              <Link href="/schedules">View Schedules</Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/reservations">My Reservations</Link>
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}

