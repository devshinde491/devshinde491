"use client"

import { useState } from "react"
import { useSession } from "next-auth/react"
import { Nav } from "@/components/nav"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"

export default function Reservations() {
  const [reservations, setReservations] = useState([
    {
      id: "1",
      train: {
        name: "Express 101",
        source: "New York",
        destination: "Washington D.C.",
        departureTime: "2023-06-01T08:00:00Z",
        arrivalTime: "2023-06-01T12:00:00Z",
      },
      seatNumber: 15,
      status: "CONFIRMED",
    },
    {
      id: "2",
      train: {
        name: "Coastal Line",
        source: "Los Angeles",
        destination: "San Francisco",
        departureTime: "2023-06-02T10:00:00Z",
        arrivalTime: "2023-06-02T18:00:00Z",
      },
      seatNumber: 22,
      status: "CONFIRMED",
    },
  ])
  const { data: session } = useSession()
  const { toast } = useToast()

  const handleCancelReservation = async (reservationId: string) => {
    console.log(`Cancelling reservation ${reservationId}`)
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-gray-100">
        <Nav />
        <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold mb-6">Please sign in to view your reservations</h1>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Nav />
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold mb-6">My Reservations</h1>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Train</TableHead>
              <TableHead>Source</TableHead>
              <TableHead>Destination</TableHead>
              <TableHead>Departure</TableHead>
              <TableHead>Arrival</TableHead>
              <TableHead>Seat Number</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {reservations.map((reservation: any) => (
              <TableRow key={reservation.id}>
                <TableCell>{reservation.train.name}</TableCell>
                <TableCell>{reservation.train.source}</TableCell>
                <TableCell>{reservation.train.destination}</TableCell>
                <TableCell>{new Date(reservation.train.departureTime).toLocaleString()}</TableCell>
                <TableCell>{new Date(reservation.train.arrivalTime).toLocaleString()}</TableCell>
                <TableCell>{reservation.seatNumber}</TableCell>
                <TableCell>{reservation.status}</TableCell>
                <TableCell>
                  <Button onClick={() => handleCancelReservation(reservation.id)} variant="destructive">
                    Cancel
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </main>
    </div>
  )
}

