import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getServerSession } from "next-auth/next"
import { authOptions } from "../auth/[...nextauth]/route"

const prisma = new PrismaClient()

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const date = searchParams.get("date")
  const source = searchParams.get("source")
  const destination = searchParams.get("destination")

  const schedules = await prisma.schedule.findMany({
    where: {
      date: date ? new Date(date) : undefined,
      train: {
        source: source || undefined,
        destination: destination || undefined,
      },
    },
    include: {
      train: true,
    },
  })

  return NextResponse.json(schedules)
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)

  if (!session || session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const data = await request.json()

  const newSchedule = await prisma.schedule.create({
    data: {
      train: {
        connect: { id: data.trainId },
      },
      date: new Date(data.date),
      status: data.status,
    },
    include: {
      train: true,
    },
  })

  return NextResponse.json(newSchedule)
}

