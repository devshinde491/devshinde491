import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getServerSession } from "next-auth/next"
import { authOptions } from "../auth/[...nextauth]/route"

const prisma = new PrismaClient()

export async function GET(request: Request) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const reservations = await prisma.reservation.findMany({
    where: {
      userId: session.user.id,
    },
    include: {
      train: true,
    },
  })

  return NextResponse.json(reservations)
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const data = await request.json()

  const train = await prisma.train.findUnique({
    where: { id: data.trainId },
  })

  if (!train || train.availableSeats === 0) {
    return NextResponse.json({ error: "No available seats" }, { status: 400 })
  }

  const newReservation = await prisma.reservation.create({
    data: {
      user: {
        connect: { id: session.user.id },
      },
      train: {
        connect: { id: data.trainId },
      },
      seatNumber: train.totalSeats - train.availableSeats + 1,
      status: "CONFIRMED",
      paymentStatus: "PENDING",
    },
    include: {
      train: true,
    },
  })

  await prisma.train.update({
    where: { id: data.trainId },
    data: { availableSeats: train.availableSeats - 1 },
  })

  return NextResponse.json(newReservation)
}

