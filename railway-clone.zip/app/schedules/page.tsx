"use client"

import type React from "react"

import { useState } from "react"
import { useSession } from "next-auth/react"
import { Nav } from "@/components/nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"

export default function Schedules() {
  const [schedules, setSchedules] = useState([
    {
      id: "1",
      train: {
        name: "Express 101",
        source: "New York",
        destination: "Washington D.C.",
        departureTime: "2023-06-01T08:00:00Z",
        arrivalTime: "2023-06-01T12:00:00Z",
        availableSeats: 50,
        price: 99.99,
      },
    },
    {
      id: "2",
      train: {
        name: "Coastal Line",
        source: "Los Angeles",
        destination: "San Francisco",
        departureTime: "2023-06-02T10:00:00Z",
        arrivalTime: "2023-06-02T18:00:00Z",
        availableSeats: 30,
        price: 129.99,
      },
    },
  ])
  const [date, setDate] = useState("")
  const [source, setSource] = useState("")
  const [destination, setDestination] = useState("")
  const { data: session } = useSession()
  const { toast } = useToast()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real application, this would fetch filtered schedules
    console.log("Searching with:", { date, source, destination })
  }

  const handleBooking = (trainId: string) => {
    if (!session) {
      toast({
        title: "Error",
        description: "Please sign in to book a ticket",
        variant: "destructive",
      })
    } else {
      console.log(`Booking for train ${trainId}`)
    }
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Nav />
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold mb-6">Train Schedules</h1>
        <form onSubmit={handleSearch} className="mb-6 flex gap-4">
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} placeholder="Date" />
          <Input type="text" value={source} onChange={(e) => setSource(e.target.value)} placeholder="Source" />
          <Input
            type="text"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            placeholder="Destination"
          />
          <Button type="submit">Search</Button>
        </form>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Train</TableHead>
              <TableHead>Source</TableHead>
              <TableHead>Destination</TableHead>
              <TableHead>Departure</TableHead>
              <TableHead>Arrival</TableHead>
              <TableHead>Available Seats</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {schedules.map((schedule: any) => (
              <TableRow key={schedule.id}>
                <TableCell>{schedule.train.name}</TableCell>
                <TableCell>{schedule.train.source}</TableCell>
                <TableCell>{schedule.train.destination}</TableCell>
                <TableCell>{new Date(schedule.train.departureTime).toLocaleString()}</TableCell>
                <TableCell>{new Date(schedule.train.arrivalTime).toLocaleString()}</TableCell>
                <TableCell>{schedule.train.availableSeats}</TableCell>
                <TableCell>${schedule.train.price.toFixed(2)}</TableCell>
                <TableCell>
                  <Button onClick={() => handleBooking(schedule.train.id)}>Book</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </main>
    </div>
  )
}

